﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace WandSpellss
{
    class LerpMovement : MonoBehaviour
    {
        public Vector3 endPoint;
        public Vector3 startPoint;
        private float duration = 2f;
        private float elapsedTime;

        public void Update() {

            
        
        }
    }
}
